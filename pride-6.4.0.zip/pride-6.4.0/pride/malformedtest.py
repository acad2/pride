import pride
client = pride.objects["->Python->Rpc_Connection_Manager->Rpc_Client"]
client.send("Malformed request to test what happens")