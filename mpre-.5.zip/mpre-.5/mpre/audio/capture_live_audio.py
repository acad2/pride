import mpre.audio.utilities as utilities
if __name__ == "__main__":
    utilities.record_wav_file(parse_args=True)