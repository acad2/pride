import sys
import mmap
import os
import pickle
import StringIO
import pprint
from contextlib import closing, contextmanager

    
import mpre.vmlibrary as vmlibrary
import mpre.defaults as defaults
import mpre.base as base
import mpre.utilities as utilities

def ensure_folder_exists(pathname, file_system="disk"):
    """usage: ensure_folder_exists(pathname)
    
       If the named folder does not exist, it is created"""
    if not os.path.exists(pathname) or not os.path.isdir(pathname):
        os.mkdir(pathname)
  
def ensure_file_exists(filepath, data=('a', '')):
    """usage: ensure_file_exists(filepath, [data=('a', '')])
        
        filepath is the absolute or relative path of the file.
        If the file does not exist, it is created
        
        data is optional. if specified, data[0] = mode and 
        data[1] = the data to be written
        
        mode should be 'a' or 'w', 'a' is the default. 
        'w' will truncate the file and the only contents
        will be the data supplied in data[1]"""
    if not os.path.exists(filepath) or not os.path.isfile(filepath):
        mode, file_data = data
        with open(filepath, mode) as _file:
            if file_data:
                _file.write(file_data)
                _file.flush()
                        
            
class Cached(object):
    """ A memoization decorator that should work with any method and argument structure"""
    cache = {}
    handles = {}
    
    def __init__(self, function):
        self.function = function
        self.cache[function] = {}
        self.handles[function] = {}
        
    def __call__(self, *args, **kwargs):
        cache = self.cache[self.function]
        handles = self.handles[self.function]
        key = str(args) + str(kwargs)
        
        if key in cache:
            result = cache[key]
            handles[key] += 1
        else:
            cache[key] = result = self.function(*args, **kwargs)
            handles[key] = 1
         
        return result
        
    def decrement_handle(self, key):
        function = self.function
        handles = self.handles[function]

        handles[key] -= 1
        if not handles[key]:
            print "deleting cached item", handles[key], key, handles.keys()
            del self.cache[function][key]
        else:
            print "references remaining for", key
        #self.handles[function][key] = handles[key]
                
 
class Directory(base.Base):
    
    defaults = defaults.Directory
    
    def __init__(self, **kwargs):
        super(Directory, self).__init__(**kwargs)
        if not self.path:
            self.delete()
            raise base.ArgumentError("Required argument 'path' not found")
        
        self.file_system, path = os.path.split(self.path)
        self.path, self.filename = os.path.split(path)
        self.parallel_method("File_System", "add", self)        
        
    def delete(self):
        for _file in self.directory[self.filename].values():
            if _file is not self:
                _file.delete()
        super(Directory, self).delete()
                
        
class File(base.Wrapper):
    """ usage: File(filename='', mode='', file=None, file_system="disk", **kwargs) => file
    
        Return a wrapper around a file like object. File objects are pickleable. 
        Upon pickling the files data will be saved and upon loading the data restored. 
        The default is False. The wrapped file can be specified by the file argument. If
        the file argument is not present, the file named in filename will be opened in the
        specified mode."""
        
    defaults = defaults.File
    
    def __init__(self, filename='', mode='', **kwargs):    
        self.filename = filename
        self.mode = mode
        super(File, self).__init__(**kwargs)
        if not self.file:
            file_system = self.file_system                            
            if file_system == "disk":                
                self.file = open(self.filename, self.mode)                
            else:
                self.file = utilities.resolve_string(self.file_type)() 
                
        self.path, self.filename = os.path.split(self.filename)
        if not self.path:
            self.path = os.path.curdir
                
        self.wraps(self.file)        
        self.parallel_method("File_System", "add", self)
                
    def handle_write(self, sender, packet):
        self.write(packet)
        
    def handle_read(self, sender, packet):
        seek, byte_count = packet.split(" ", 1)
        self.seek(seek)
        return "handle_write " + self.read(byte_count)
                        
    def __getstate__(self):
        attributes = super(File, self).__getstate__()
        backup_tell = self.tell()
        self.seek(0)
        attributes["_file_data"] = self.read()
        self.seek(backup_tell) # in case other objects use it (arguably bad practice anyway)
        del attributes["wrapped_object"]
        return attributes
        
    def on_load(self, attributes):
        super(File, self).on_load(attributes)
        _file = open(self.filename, self.mode)
        self.wraps(_file)
        self.write(self.__dict__.pop("_file_data"))                        
        self.seek(0)
            
    def delete(self):
        super(File, self).delete()
        self.wrapped_object.close()
       #if self.directory and self.filename in self.directory:
        del self.directory
                
        
class Encrypted_File(File):
    """ usage: Encrypted_File(_file, **kwargs) => encrypted_file
               
        Returns an Encrypted_File object. Calls to the write method will be encrypted with
        encrypted_file.key via the mpre.utilities.convert function, and reads will be decrypted using the same key. Currently only supports ascii.
        
        The key is only valid for as long as the instance exists. In order to preserve
        the key, utilize the save method. The resulting pickle stream can later be
        unpickled and supplied to the load method to recover the original instance with 
        the appropriate key to decrypt the file."""
        
    asciikey = ''.join(chr(ordinal) for ordinal in xrange(256))
    
    def __init__(self, filename='', mode='', file=None, file_system='disk', **kwargs):
        super(Encrypted_File, self).__init__(filename, mode, file, file_system, **kwargs)
        self.key = ''.join(ordinal for ordinal in self.derive_key())
    
    def derive_key(self):
        key = set()
        while len(key) < 256:
            key.update(set(os.urandom(256)))
        return key
    
  #  def write(self, data):
   #     self.wrapped_object.write(self.encrypt(data))
        
   # def read(self, size=-1):
    #    print "Reading encrypted file", self.filename
     #   return self.decrypt(self.wrapped_object.read(size))
        
    def encrypt(self, data):
        return utilities.convert(data, Encrypted_File.asciikey, self.key)
        
    def decrypt(self, data):
        return utilities.convert(data, self.key, Encrypted_File.asciikey)
        

class File_System(base.Base):
            
    defaults = defaults.File_System
    
    def __init__(self, **kwargs):
        super(File_System, self).__init__(**kwargs)
        self.current_working_directory = {}
        for file_system in self.file_systems:
            setattr(self, file_system, {os.path.curdir : {}})        
            if file_system == "disk":
                self.change_directory(self.join(file_system, os.getcwd()))
            else:
                self.change_directory(self.join(file_system, ''))
    
    def join(self, path_one, path_two):
        return os.path.sep.join((path_one, path_two))
            
    def listdir(self, path):
        _, is_file = os.path.splitext(path)
        if is_file:
            raise IOError("Path '{}' is not a directory".format(path))
        return self.get_file(path).keys()
        
    def new_file_system(self, file_system):
        setattr(self, file_system, {})
        self.change_directory(self.join(file_system, os.getcwd()))
        self.file_systems += (file_system, )
        
    def add(self, _file):      
        directory = self.get_file(self.join(_file.file_system, _file.path))
        if _file.is_directory:
            print "adding directory:", 
            value = {}
        else:
            value = _file
        directory[_file.filename] = value
        _file.directory = directory
        super(File_System, self).add(_file)
        
    def __str__(self):
        backup = sys.stdout
        log = sys.stdout = StringIO.StringIO()
        for file_system in self.file_systems:
            print "\n{}:".format(file_system)
            _file_system = getattr(self, file_system)
            current_working_directory = os.path.curdir
            removed = _file_system.pop(current_working_directory)
            pprint.pprint(_file_system)
            _file_system[current_working_directory] = removed
        sys.stdout = backup
        log.seek(0)
        return log.read()
        
    def change_directory(self, path):
        file_system, _path = path.split(os.path.sep, 1)
        directory = self.get_file(path)
        self.current_working_directory[file_system] = (path, directory)
        file_system = getattr(self, file_system)
        file_system[os.path.curdir] = directory
        
    def getcwd(self, file_system):
        return self.current_working_directory[file_system][0]
        
    def __getitem__(self, path):
        return self.get_file(path)
        
    def get_file(self, path):  
        file_system, path = path.split(os.path.sep, 1)
        _path, is_file = os.path.splitext(path)
        lookup_chain = path.split(os.path.sep)
        _filename = lookup_chain.pop(-1) if is_file else None
        _file_system = file_system
        file_system = getattr(self, file_system) 
     #   print "\nGetting file; path:", path
      #  print "Lookup chain: ", lookup_chain
        if not lookup_chain:
            directory = file_system[os.path.curdir]
        else:
            directory = file_system
            for progress, key in enumerate(lookup_chain):
                try:
              #      print "\nLooking for node: ", key, directory.keys()
                    directory = directory[key]
                except KeyError:             
                    current_directory = os.path.sep.join(lookup_chain[:progress + 1])
              #      print "node {} does not exist".format(current_directory)
                    if not is_file:
                        if _file_system != "disk" or os.path.exists(current_directory):
               #             print "creating node {}".format(key)
                            directory[key] = {}
                            directory = directory[key]
                   #         _directory = Directory(path=current_directory)
                            #pprint.pprint(directory)
                        else:
                            raise IOError("Directory '{}' does not exist".format(current_directory))
                    else:
                        pprint.pprint(file_system)
                        raise IOError("File '{}' does not exist".format(current_directory))
                
        #pprint.pprint(file_system)        
        result = directory
        if _filename is not None:
            try:
                result = directory[_filename]
            except KeyError:
                file_not_found = "File '{}' does not exist in {} file system"
                raise IOError(file_not_found.format(path, _file_system))
        return result
        
    def remove(self, _file, file_system="disk"):
        super(File_System, self).remove(_file)
        directory = (self.get_file(os.path.join(_file.file_system, _file.path)) if not 
                     _file.directory else _file.directory)
        del directory[_file.filename]
          
        
class Mmap(object):
    """Usage: mmap [offset] = fileio.Mmap(filename, 
                                          file_position_or_size=0,
                                          blocks=0)
                                 
        Return an mmap.mmap object. Use of this class presumes a
        need for a slice into a potentially large file at an arbitrary
        point without loading the entire file contents. These slices
        are cached so that further requests for the same chunk will return the same mmap.
        
            - if filename is -1 (a chunk of anonymous memory), then no 
              offset is returned. the second argument is interpreted
              as the desired size of the chunk of memory.
            - if filename is specified, the second argument is
              interpreted as the index into the file the slice
              should be opened to.
            
            The default value for the second argument is 0, which will
            open a slice at the beginning of the specified file
            
            - the blocks argument may be specified to request the
              mapping to be of size (blocks * mmap.ALLOCATIONGRANULARITY)
            - this argument has no effect when used with -1 for the filename            
            """    
    def __new__(cls, filename, file_position=0, blocks=0):
        if filename is -1:
            result = mmap.mmap(-1, file_position)
        else:
            result = Mmap.new_mmap(filename, file_position, blocks)
        return result
    
    @Cached
    def new_mmap(filename, file_position, blocks):
        file_size = os.path.getsize(filename)
        if file_position >= file_size or file_position < 0:
            raise ValueError             
        
        chunk_size = mmap.ALLOCATIONGRANULARITY
        chunk_number, data_offset = divmod(file_position, chunk_size)
        #blocks = min(self.max_blocks_per_mmap, blocks)
                                           
        # calculate the data's displacement + offset into file
        request_size = file_size if file_size <= chunk_size else chunk_size
        request_size = blocks * chunk_size if blocks else request_size
        
        if file_size - file_position < request_size:
            length = file_size - chunk_number * chunk_size
            data_offset = file_position - chunk_number * chunk_size
        else:
            length = request_size
                     
        with open(filename, 'rb') as file_on_disk:
            file_number = file_on_disk.fileno()
        
        args = (file_number, length)        
        kwargs = {"access" : mmap.ACCESS_READ,
                  "offset" : chunk_number * chunk_size}
        
        memory_map = mmap.mmap(*args, **kwargs)
                
        return memory_map, data_offset

    
if __name__ == "__main__":
    def test_case1(filename, iterations=1000):
        for x in xrange(iterations):
            f = open(filename, 'rb')
            f.close()
    
    def test_case2(filename, iterations=1000):
        for x in xrange(iterations):
            f = File(filename, 'rb')
    
    from mpre.misc.decoratorlibrary import Timed
    
    time = Timed(test_case1)("demofile.exe")
    time2 = Timed(test_case2)("demofile.exe")
    print "open: ", time
    print "Cache:", time2
    
    """def test_case(filename, file_position, iterations=100):
        for x in xrange(iterations):
            m, offset = Mmap(filename, file_position)
            
        print "opened at: ", file_position
        print "Data offset into block: ", offset
        print ord(file_data[file_position]), ord(m[offset])
        assert file_data[file_position] == m[offset] 
        
    m, offset = Mmap("demofile.exe", 22892790) 
    demofile = "demofile.exe"
    _file = File(demofile, 'rb')
    file_data = _file.read()
    file_size = len(file_data)
    print
    print "file size: ", file_size
    print
    
    for file_position in (22892790, 0, file_size-1):
        print "testing", file_position
        test_case(demofile, file_position, iterations=2)"""
        
    """for x in xrange(100):
        m, offset = io_manager.load_mmap("newrecording.wav", 2913000)
    for y in xrange(100):
        m2, offset2 = io_manager.load_mmap("testrecording.wav", 3113000)
    
    for x in xrange(10):
        io_manager.load_mmap("newrecording.wav", 3112997)"""