#   mpf.decoratorlibrary - decorators particularly useful with the runtime decorator
#
#    Copyright (C) 2014  Ella Rose
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

import sys
import trace
import time
import inspect
import StringIO
from test import pystone
from functools import wraps
from weakref import ref

seconds, pystones_per_second = pystone.pystones(pystone.LOOPS)

class Pystone_Test(object):
    
    def __init__(self, function):
        self.function = function
        
    def __call__(self, *args, **kwargs):
        if sys.platform == "win32":
            timer = time.clock
        else:
            timer = time.time
        start_time = timer()
        try:
            result = self.function(*args, **kwargs)
        except:
            end_time = timer()
            time_taken = end_time-start_time
            pystones_result = time_taken/pystones_per_second
            print "%s crashed after %s pystones of work" % (self.function, pystones_result)
            print "local variables: ", locals(), "\n"
            raise
        else:
            end_time = timer()
            time_taken = end_time-start_time
            pystones_result = time_taken/pystones_per_second
            print "%s took %s pystones to perform" % (self.function, pystones_result)
            return result
     
    
class Timed(object):
    
    def __init__(self, function):
        self.function = function
        if sys.platform == "win32":
            self.timer = time.clock
        else:
            self.timer = time.time       
    def __call__(self, *args, **kwargs):
        timer = self.timer
        start = timer()
        try:
            result = self.function(*args, **kwargs)
        except:
            end = timer()
            print "%s crashed after %ss" % (self.function, end-start)
            print "local variables: ", locals(), "\n"
            raise
        else:
            end = timer()
            run_time = end - start
            return run_time, result
                        
class Tracer(object):
    "'call', 'line', 'return', 'exception', 'c_call', 'c_return', or 'c_exception'"
    def __init__(self, function):
        self.function = function
        self.source = ''
        self.debug = ''
        self.print_mode = "source"
        self.function_source = ''
     
    def get_frame_info(self, frame):
        code = frame.f_code
        call_info = {"code" : code,
                     "function_name" : code.co_name,
                     "line_number" : frame.f_lineno,
                     "called_from" : code.co_filename}                                
                    
        caller = frame.f_back
        caller_code = caller.f_code
        caller_info = {"caller" : caller,
                       "code" : caller_code,
                       "line_number" : caller.f_lineno,
                       "function_name" : caller_code.co_name}   
                       
        if not self.function_source:
            self.function_source = inspect.getsource(code)
            module = code.co_filename.split("\\")[-1].replace(".py", "")
            self.function_module_source = inspect.getsource(__import__(module))
            self.caller_source = inspect.getsource(caller_code)           
        return call_info, caller_info

    def trace(self, frame, event, arg):
        call_info, caller_info = self.get_frame_info(frame)
        local_trace = None
        function_name = call_info["function_name"]
        frame_locals = frame.f_locals
        if call_info["function_name"] == "write":
            pass # ignore print calls
        elif event == "return":
            self.source += "returned %s\n" % type(arg)
            self.debug += "%s returned %s\n" % (function_name, arg)
        else:
            source = self.function_module_source.split("\n")[call_info["line_number"]-1] + "\n"
            for attribute, value in frame_locals.items():
                source = source.replace(attribute, str(value))
            self.source += source
            self.debug += "call to %s from %s line %s\n" % \
            (function_name, call_info["called_from"], call_info["line_number"])
            local_trace = self.trace            
        return local_trace
        
    def __call__(self, *args, **kwargs):
        old_trace = sys.gettrace()
        sys.settrace(self.trace)
        results = self.function(*args, **kwargs)
        sys.settrace(old_trace)
        if "debug" in self.print_mode:
            print self.debug
        if "source" in self.print_mode:
            print self.source
        return results
          
    
class Dump_Source(Tracer):
    """Tracer decorator that dumps source code to disk instead of writing to sys.stdout."""
    
    def __init__(self, function):
        super(Dump_Source, self).__init__(function)
        
    def __call__(self, *args, **kwargs):
        old_stdout = sys.stdout
        with open("%s_source.txt" % self.function.func_name, "w") as file:
            sys.stdout = file
            super(Dump_Source, self).__call__(*args, **kwargs)
            sys.stdout = old_stdout
            file.close()
            
            
class Argument_log(object):

    def __init__(self, function):
        self.function = function

    def __call__(self, *args, **kwargs):
        print "\calling %s with args: %s and kwargs: %s" % (self.function, args, kwargs)
        return self.function(*args, **kwargs)
        print "call to %s complete" % self.function           