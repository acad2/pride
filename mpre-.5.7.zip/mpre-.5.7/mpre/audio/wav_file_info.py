import mpre.audio.utilities as utilities

if __name__ == "__main__":
    utilities.wav_file_info(parse_args=True)