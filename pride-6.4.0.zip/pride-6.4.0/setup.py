from setuptools import setup

#with open(".\\pride\\readme.md", 'r') as _file:
#    long_description = _file.read()
    
options = {"name" : "pride",
           "version" : "6.4.0",
           "description" : "Python runtime and integrated development environment",
           "long_description" : '',
           "url" : "https://github.com/erose1337/pride",
           "download_url" : "https://github.com/erose1337/pride/archive/master.zip",
           "author" : "Ella Rose",
           "author_email" : "erose1337@hotmail.com",
           "packages" : ["pride", "pride.audio", "pride.gui", "pride.programs"],
           #"scripts" : ["main.py"],
           "package_data" : {"pride.gui" : ["gui\\libfreetype-6.dll", 
                                            "gui\\SDL2.dll", "gui\\SDL2_ttf.dll",
                                            "gui\\sdlgfx.dll", "gui\\zlib1.dll",
                                            "gui\\sdlgfx.lib"]},
           "classifiers" : ["Development Status :: 3 - Alpha", 
                            "Intended Audience :: Developers",
                            "Intended Audience :: End Users/Desktop",
                            "Operating System :: Microsoft :: Windows",
                            "Operating System :: POSIX :: Linux",
                            "Programming Language :: Python :: 2.7",
                            "Topic :: Desktop Environment", "Topic :: Documentation",
                            "Topic :: Games/Entertainment", "Topic :: Multimedia :: Sound/Audio",
                            "Topic :: Software Development :: Compilers", 
                            "Topic :: Software Development :: Code Generators",
                            "Topic :: Software Development :: Build Tools",
                            "Topic :: Software Development :: Libraries :: Application Frameworks",
                            "Topic :: Software Development :: Libraries :: Python Modules",
                            "Topic :: Software Development :: Pre-processors",
                            "Topic :: Software Development :: User Interfaces",
                            "Topic :: Software Development :: Widget Sets",
                            "Topic :: System :: Distributed Computing",
                            "Topic :: System :: Shells", 
                            "Topic :: Text Editors :: Integrated Development Environments (IDE)"]
                            }
setup(**options)