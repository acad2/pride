print __file__
print dir()
print __package__