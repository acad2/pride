import mpre

if __name__ == "__main__":
    mpre.Instruction("Metapython", "create", "network2.File_Service", parse_args=True).execute()