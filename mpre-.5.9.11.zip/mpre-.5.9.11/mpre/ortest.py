def or_test(value=0):
    value = value or 1337
    
def if_test(value=0):
    if not value:
        value = 1337
        
from mpre.misc.decoratorlibrary import Timed

print Timed(or_test, iterations=10000)()
print Timed(if_test, iterations=10000)()        