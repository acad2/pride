import struct
import functools
import traceback
import json
import pickle

import pride
import pride.base
import pride.network
import pride.networkssl
import pride.authentication
import pride.persistence
import pride.decorators
objects = pride.objects

default_serializer = pickle
_old_data, _hosts = {}, {}

def packetize_send(send):
    def _send(self, data):
        return send(self, str(len(data)) + ' ' + data)   
    return _send
    
def packetize_recv(recv):
    def _recv(self, buffer_size=0):
        try:
            data = _old_data[self] + recv(self, buffer_size)
        except KeyError:
            data = recv(self, buffer_size)            
        _old_data[self] = ''
        packets = []
        while data:
            try:
                packet_size, data = data.split(' ', 1)
            except ValueError:
                _old_data[self] = data
                break
            packet_size = int(packet_size)
            packets.append(data[:packet_size])
            data = data[packet_size:]   
        return packets    
    return _recv
   
        
class Session(pride.base.Base):
    
    defaults = {"id" : '0', 
                "host_info" : tuple(),
                "requester_type" : "pride.rpc.Rpc_Client"}
    
    def _get_id(self):
        return self._id
    def _set_id(self, value):
        self._id = value
        self.id_size = struct.pack('l', len(value))
    id = property(_get_id, _set_id)
    
    def _get_context(self):
        return self.id, self.host_info
    context = property(_get_context)
    
    def __init__(self, session_id, host_info, **kwargs):
        self._callbacks = []
        super(Session, self).__init__(**kwargs)
        self.id = session_id
        self.host_info = host_info
            
    def execute(self, instruction, callback):
        request = ' '.join((self.id_size + self.id, 
                            instruction.component_name, instruction.method, 
                            default_serializer.dumps((instruction.args, 
                                                      instruction.kwargs))))
        try:
            host = _hosts[self.host_info]
        except KeyError:
            host = _hosts[self.host_info] = self.create(self.requester_type,
                                                        host_info=self.host_info)
        if host.bypass_network_stack and host._endpoint_instance_name:
            self._callbacks.insert(0, callback)
        else:
            self._callbacks.append(callback)
      #  self.alert("Storing callback: {}. callbacks: {}".format(callback, self._callbacks), level=0)  
        host.make_request(request, self.instance_name)
       
    def __next__(self): # python 3
        return self._callbacks.pop(0)
      
    def next(self): # python 2   
        return self._callbacks.pop(0)
        
            
class Packet_Client(pride.networkssl.SSL_Client):
            
    defaults = {"_old_data" : bytes()}
    
    @packetize_send
    def send(self, data):
        return super(Packet_Client, self).send(data)
    
    @packetize_recv
    def recv(self, buffer_size=0):
        return super(Packet_Client, self).recv(buffer_size)      
        
        
class Packet_Socket(pride.networkssl.SSL_Socket):
            
    defaults = {"_old_data" : bytes()}
    
    @packetize_send
    def send(self, data):
        return super(Packet_Socket, self).send(data)
    
    @packetize_recv
    def recv(self, buffer_size=0):        
        return super(Packet_Socket, self).recv(buffer_size)
                       
                        
class Rpc_Server(pride.networkssl.SSL_Server):
    
    defaults = {"port" : 40022,
                "interface" : "localhost",
                "Tcp_Socket_type" : "pride.rpc.Rpc_Socket"}
    
    
class Rpc_Client(Packet_Client):
               
    def __init__(self, **kwargs):
        self._requests, self._callbacks = [], []
        super(Rpc_Client, self).__init__(**kwargs)
        
    def on_ssl_authentication(self):
        count = 1
        length = len(self._requests)
        for request, callback in self._requests:
            self.alert("Making delayed request {}/{}: {}".format(count, length, request)[:128], level='vv')
            self._callbacks.append(callback)  
            self.send(request)
            
    def make_request(self, request, callback_owner):
        if not self.ssl_authenticated:
            self.alert("Delaying request until authenticated: {}".format(request)[:128], level='vv')
            self._requests.append((request, callback_owner))
        else:    
            self.alert("Making request for {}".format(callback_owner), level='v')
            self._callbacks.append(callback_owner)
            self.send(request)            
        
    def recv(self, packet_count=0):
        for response in super(Rpc_Client, self).recv():
         #   print "Deserealizing: ", len(response), response
            _response = self.deserealize(response)
            callback_owner = self._callbacks.pop(0)
            try:
                callback = next(pride.objects[callback_owner])
            except KeyError:
                self.alert("Could not resolve callback_owner '{}' for {} {}",
                           (callback_owner, "callback with arguments {}",
                            _response), level=0)
            else:
                if isinstance(_response, BaseException):
                    self.handle_exception(callback, _response)
                elif callback is not None:
                    callback(_response)                                
                                                
    def handle_exception(self, callback, response):
        self.alert("Exception {} from rpc with callback {}",
                   (getattr(response, "traceback", response), callback), 
                   level=0)
        if (isinstance(response, SystemExit) or 
            isinstance(response, KeyboardInterrupt)):
            print "Reraising exception", type(response)()
            raise type(response)()            
            
    def deserealize(self, response):
        return default_serializer.loads(response)
        
        
class Rpc_Socket(Packet_Socket):
            
    defaults = {"debug_mode" : True}
                    
    def recv(self, packet_count=0):
        peername = self.peername
        for packet in super(Rpc_Socket, self).recv():
            session_id_size = struct.unpack('l', packet[:4])[0]
            end_session_id = 4 + session_id_size
            session_id = packet[4:end_session_id]
            (component_name, method, 
             serialized_arguments) = packet[end_session_id + 1:].split(' ', 2)

           # print "\nsession id: ", len(session_id), session_id
           # print "\ninstance: ", component_name
           # print "\nmethod: ", len(method), method
           # print "\narguments: ", serialized_arguments[:128], ' ...'
            
            permission = False
            if session_id == '0': 
                if method in ("register", "login"):
                    permission = True
            try:
                instance = pride.objects[component_name]
            except KeyError as result:
                pass
            else:
                if not hasattr(instance, "validate"):
                    result = pride.authentication.UnauthorizedError()
                elif (permission or 
                    instance.validate(session_id, peername, method)):
                    instance.current_session = (session_id, peername)
                    try:
                        args, kwargs = self.deserealize(serialized_arguments)
                        result = getattr(instance, method)(*args, **kwargs)
                    except BaseException as result:
                        stack_trace = traceback.format_exc()
                        self.alert("Exception processing request {}.{}: \n{}",
                                   [component_name, method, stack_trace],
                                   level='vv')
                        if isinstance(result, SystemExit):
                            raise                                   
                        result.traceback = stack_trace
                else:
                    self.alert("Denying unauthorized request: {}",
                               (packet, ), level='v')
                    result = pride.authentication.UnauthorizedError()
            self.alert("Sending result of {}.{}: {}",
                       (instance, method, result), level='vv')
            self.send(self.serealize(result))
            
    def deserealize(self, serialized_arguments):
        return default_serializer.loads(serialized_arguments)
        
    def serealize(self, result):
        return default_serializer.dumps(result)
