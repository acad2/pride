from setuptools import setup

setup(name="mpre",
      version=".5.35",
      description="A dynamic runtime environment with a simple concurrency model",
      url="https://github.com/erose1337/Metapython",
      author="Ella Rose",
      author_email="erose1337@hotmail.com",
      packages=["mpre", "mpre.audio", "mpre.gui", "mpre.misc", "mpre.programs"])